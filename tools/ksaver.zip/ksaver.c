/*
	ksaver.c

ksaver.bas $B$G%;!<%V$7$?(B d88$B%U%!%$%k$+$i!"(BROM$B%$%a!<%8$rCj=P$7$^$9!#(B

*/

#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#define byte unsigned char

int confirm(char* path);
byte* read_d88sector(int kai, int drive ,int track ,int sector);
void dump(char *buff,int length);
void filer(void);
int read_dir();
void read_fat(void);
int  input_file(int idx);
int  output_file(char *path);

struct _sector {
  char  c;
  char  h;
  char  r;
  char  n;
  short sectors;
  char  mitudo;
  char  deleted;
  char  status;
  char  reserve[5];
  short size;
 } d88sector;


FILE *DskStream;		// $BF~NO%U%!%$%kMQ(B

struct _dir {			// $B%G%#%l%/%H%j!<(B
  char path[16];			// $B%U%!%$%kL>(B
  int  start;				// $B3+;O%/%i%9%?!<HV9f(B
 } dir[192];
int max_dir;			// $BEPO?$5$l$F$$$k%G%#%l%/%H%j!<?t(B

byte fat[256];			// FAT (File Allocation Table)
byte buffer[64*1024];	// $B$H$j$"$($:!"Bg$-$a$N%P%C%U%!(B $B$r$H$C$F$*$/(B



/* **************** main ************************* */
int main(int argc,char *argv[])
{
 if( argc>1)
   {
    if( confirm(argv[1]))
		{
	    DskStream= fopen(argv[1] ,"rb");
	    if( DskStream==NULL) { printf("open error %s",argv[1]); exit(0);}
	    filer();
	    fclose( DskStream);
		}
	else
		{
		 printf("\n %s : Goodby ...\n",argv[0]);
		}
   }
 else
	{
	 printf("usage: %s  [.d88 file]\n",argv[0]);
	}
 return(0);
}

/* **************** confirm ************************* */
int confirm(char* path)
{
 int ret;
 char buff[101];

    ret=0;
	printf("ksaver.c : Convert '%s' to romfiles \n",path);
	printf("Ready?  (y/n)");
	fgets(buff,100,stdin);
	if( buff[0]=='y' || buff[0]=='Y')
		{
		 ret=1;
		}
 return(ret);
}


/* **************** filer *************************** */
void filer(void)
{
 char  *infile[]={"KROM1","KROM2","KROM3","KROM4"};
 int i;
 int idx;
 int result;

 result=0;
 read_dir();		// read directory
 read_fat();		// read FAT
 for(i=0; i<5;i++)
	{
	 idx = search_dir( infile[i]);
	 if( idx >=0)
		{
		 input_file(idx);
		 output_file( infile[i] );
		 result++;
		}
	}
 if( result==0)
	{
	 printf("Not found   any ROM files  in this D88 file.\n");
	}
}

/* **************** $B%U%!%$%kFI$_9~$_(B *************************** */
int input_file(int idx)
{
int i;
int len;				// $BO"B3$7$FFI$_9~$`%;%/%??t(B
byte cluster;			// $B8=:_$N%/%i%9%?HV9f(B
int c,h,r,n;
byte *po;

  printf("Load : %s...",dir[idx].path);
  i=0;
  len=8;				// $B%/%i%9%?$NA4D9(B
  po =buffer;
  cluster = dir[idx].start;				// first cluster
  do {
//	 printf("cluster =%X \n",cluster); getch();
     if( cluster >= 0xc1 &&  cluster <=0xc8)	// Last cluster?
		{
		 len= cluster & 0xf;			// length
		}

     c = (int)(cluster /2);				// cylinder
     r = (cluster% 2)*8;				// record
     memcpy(po ,read_d88sector(len,0,c,r), len*256);
     po+= len*256;
     cluster =fat[cluster];				// next cluster
     i++; if( i>31) break;				// buffer limitter
    }
  while( cluster <0xc1 || cluster >0xc8);
  printf("Ok\n");
 return(0);
}


/* **************** $B%U%!%$%k=q$-9~$_(B  (BSAVE $B7A<0BP1~(B) ******************** */
int output_file(char *path)
{
 FILE *fp;
 int start;
 int end;
 int len;
 int i;

 start = buffer[1]*256+buffer[0];
 end   = buffer[3]*256+buffer[2];
 len   = end-start;

 fp= fopen( path,"wb");
 if(NULL==fp) {printf("write open error %s \n",path); return(-1);}

 printf("Save : %s...",path );
 for(i=4; i< len+4;i++)
	{
	 fputc( buffer[i],fp);
	}
 fclose(fp);
 printf("Ok\n");
 return(0);
}


/* ******************** $B%U%!%$%k8!:w(B ******************************* */
int search_dir(char *path)
{
 char buff[256];
 int i;
 int ret;

 ret=-1;
 for(i=0; i< max_dir ;i++)
	{
	 if( strncmp(path ,dir[i].path,strlen(path))==0)
		{
//		 printf("Found: %s \n",path);
         ret=i;
		 break;
		}
	}
  return( ret);
}


/* ******************** $B%U%!%$%kA*Br(B ******************************* */
int sel_dir()
{
 char buff[256];
 int i;
 for(i=0; i< 25	;i++)
	{
	 printf("%d: %s\n",i,dir[i].path);
	}
 printf("Input file Number ? (0-%d)",max_dir);
 fgets(buff,256,stdin);
 return( atoi(buff));
}



/* ******************** $B%G%#%l%/%H%jFI$_9~$_(B *********************** */
int read_dir()
{
 int i;
 byte buff[16*256];

    memcpy(buff ,read_d88sector(12,0,37,0),12*256);
	for(i=0;i<192; i++)
		{
		 if( buff[i*16]==0xff) {
			max_dir= i;
		 	break;
                 		}
		 memcpy( dir[i].path     ,&buff[i*16],9);
		 dir[i].path[10]= 0x00;
		 dir[i].start   = buff[i*16+10];
//		 printf("%s  %X\n",dir[i].path ,dir[i].start);
		}
return(0);
}


// ********************* FAT $BFI$_9~$_(B *******************************
void read_fat(void)
{
    memcpy(fat ,read_d88sector(1,0,37,14),256);
//    printf("fat=="); dump(fat,256);
}


byte* read_d88sector(int kai, int drive ,int track ,int sector)
{
       int i;
       byte *p;
       static byte buff[16*256];
       long adr;
//       printf("read_d88sector(): ");

       memset(buff,0,16*256);
       if( DskStream) {
           p=buff;
            adr=0x2b0+track*(256+16)*16+ sector*(256+16);
//            printf(" READ: track  sector  adr  %d,%d,%06lX  \n",track,sector+1,adr);
            if( fseek(DskStream ,adr, SEEK_SET)!=0)
                 {printf("Seek error           c=%d  adr=%4X  \n",track ,adr); return(buff);}

           for(i=0; i< kai ; i++, p+=256)		// kaisuu kurikaesu
             {
               if( fread( &d88sector ,sizeof(d88sector),1, DskStream)!=1)
                   {printf("Read error           c=%d \n",track); return(buff);}

              if( fread( p , 256,1,DskStream)!=1)
                   { printf("Read error data c=%d  \n",track); return(buff);}

           }
        }
   return( buff);
}


void dump(char *buff,int length)
{
 int i,j;
 printf("------------------------------------------------------\n");
 for( i=0; i< length; i+=16)
   {
    printf("%04X :",i & 0xffff);
    for( j=0; j<16; j++)
      {
       char c= *(buff+i+j);
       printf("%02X ",c & 0xff);
      }
    for( j=0; j<16; j++)
      {
       char c= *(buff+i+j);
       printf("%c",c <0x20 ? 0x2e: c);
      }
    printf("\n");
//    if( i ==0x80|| i==0xf8) { getch();}
   }
}
